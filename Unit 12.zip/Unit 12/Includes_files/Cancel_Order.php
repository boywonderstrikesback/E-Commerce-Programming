<?php
mysqli_query($link, "SET AUTOCOMMIT = 0");
$select_supplements = "SELECT supplements_id, quantity from supplement_orders_supplements WHERE supplement_orders_id = $supplement_orders_id";
$exec_select_supplements = @mysqli_query($link, $select_supplements);
if(!$exec_select_supplements){
	rollback('Ordered hats could not be retrieved becase '.mysqli_error($link));
}else{
	while($one_record = mysqli_fetch_assoc($exec_supplement_hats)){
		$quantity = $one_record['quantity'];
		$hats_id = $one_record['supplements_id'];
		$update_supplements = "UPDATE supplements set stock_quantity = (stock_quantity+$quantity) WHERE supplements_id = $supplements_id";
		$exec_update_hats = @mysqli_query($link, $update_supplements);
		if(!$exec_select_supplements){
			rollback('Update was not successful becase '.mysqli_error($link));
		}
	}
	$delete_order = "DELETE supplement_shipping_addresses.*, supplement_billing_addresses.*, supplement_transactions.* FROM supplement_orders 
	INNER JOIN hat_billing_addresses USING (supplement_billing_addresses_id)
	INNER JOIN hat_shipping_addresses USING (supplement_shipping_addresses_id)
	INNER JOIN hat_transactions USING (supplement_transactions_id)
	WHERE supplement_orders_id = $supplement_orders_id";
	$exec_delete_order = @mysqli_query($link, $delete_order);
	if(!$exec_delete_order){
		rollback('Delete was not successful becase '.mysqli_error($link));
	}else{
		mysqli_query($link, "COMMIT");
		redirect('successfully deleted...', 'view_current_orders.php', 1);
	}	
}
?>