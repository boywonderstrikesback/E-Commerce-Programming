<?php
DEFINE('HOST', 'localhost');
DEFINE('USER', 'aarslanyilmaz');
DEFINE('PASS', '');
DEFINE('DB', 'ecommerce1');

?>