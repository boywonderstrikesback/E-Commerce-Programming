USE ecommerce


CREATE TABLE  bjj_matches (
	bjj_matches_id TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
	Opponent VARCHAR(30) NOT NULL,
    Win_Loss VARCHAR(30) NOT NULL,
	Method VARCHAR(30) NOT NULL,
	PRIMARY KEY (bjj_matches_id)
) ENGINE = InnoDB;

INSERT INTO bjj_matches(Opponent,Win_Loss,Method) VALUES
	('Unkown','Win','Refee Stoppage'),
	('Unkown','Loss','Darce'),
	('Rocc Lafonce','Win' ,'Guillotine'),
	('Benjamin Lance', 'Loss','Advantage'),
    ('Mike Glenn', 'Loss', 'Darce' ),
    ('Rob Hazon','win','Rear Naked choke'),
	('Mike Merlo','win','Guillotine Choke'),
	('Dave Rogers', 'Win','Darce Choke');


	CREATE TABLE bjj_matches( (
	bjj_matches_id MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT, 
	first_name VARCHAR(30) NOT NULL,
	last_name VARCHAR(30) NOT NULL,
	email VARCHAR(40) NOT NULL,
	phone VARCHAR(20) NOT NULL,
	password CHAR(255) NOT NULL,
	address_1 VARCHAR(100) NOT NULL,
	address_2 VARCHAR(100),
	city VARCHAR(50) NOT NULL,
	hat_states_id TINYINT UNSIGNED NOT NULL,
	zip CHAR(5) NOT NULL,
	date_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY(bjj_matches_id),
	INDEX ind_hat_states_id (bjj_matches_id),
	CONSTRAINT fk_hat_states_id FOREIGN KEY (bjj_matches_id) REFERENCES bjj_matches(bjj_matches_id) ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE = InnoDB;

create table bjj_transactions(
	bjj_transactions_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	amount_charged DECIMAL(6, 3) NOT NULL, 
	type VARCHAR(100) NOT NULL, 
	response_code VARCHAR(200) NOT NULL, 
	response_reason VARCHAR(200) NOT NULL, 
	response_text VARCHAR(400) NOT NULL, 
	date_created TIMESTAMP NOT NULL, 
	PRIMARY KEY9(bjj_matches_id)
) ENGINE = InnoDB;

create table shipping_addresses(
	shipping_addresses_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	address_1 VARCHAR(100) NOT NULL, 
	address_2 VARCHAR(100), 
	city VARCHAR(50) NOT NULL, 
	hat_states_id TINYINT UNSIGNED NOT NULL, 
	zip CHAR(5) NOT NULL, 
	date_created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY(hat_shipping_addresses_id)
) ENGINE = InnoDB;

create table billing_addresses(
	billing_addresses_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	address_1 VARCHAR(100) NOT NULL, 
	address_2 VARCHAR(100), 
	city VARCHAR(50) NOT NULL, 
	hat_states_id TINYINT UNSIGNED NOT NULL, 
	zip CHAR(5) NOT NULL, 
	date_created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY(hat_billing_addresses_id)
) ENGINE = InnoDB;

create table carriers_methods(
	hat_carriers_methods_id TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
	carrier VARCHAR(50) NOT NULL, 
	method VARCHAR(50) NOT NULL, 
	fee DECIMAL(6, 3) NOT NULL, 
	PRIMARY KEY(hat_carriers_methods_id)
) ENGINE = InnoDB;

INSERT INTO carriers_methods (carrier, method, fee) VALUES 
('UPS', 'Ground', '4.99'),


create table orders(
	orders_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
	hat_customers_id MEDIUMINT UNSIGNED NOT NULL,
	transactions_id INT UNSIGNED NOT NULL,
	shipping_addresses_id INT UNSIGNED NOT NULL,
	carriers_methods_id TINYINT UNSIGNED NOT NULL,
	billing_addresses_id INT UNSIGNED NOT NULL,
	credit_no CHAR(4) NOT NULL, 
	credit_type VARCHAR(20) NOT NULL, 
	order_total DECIMAL(7, 3) NOT NULL, 
	shipping_fee DECIMAL(6, 3) NOT NULL, 
	order_date TIMESTAMP NOT NULL, 
	shipping_date TIMESTAMP NOT NULL, 
	PRIMARY KEY(orders_id),
	INDEX ind_hat_customers_id (customers_id),
	CONSTRAINT fk_hat_customers_id FOREIGN KEY (customers_id) REFERENCES hat_customers(customers_id)
	ON DELETE CASCADE on UPDATE CASCADE,
	INDEX ind_hat_transactions_id (transactions_id),
	CONSTRAINT fk_hat_transactions_id FOREIGN KEY (transactions_id) REFERENCES transactions(transactions_id)
	ON DELETE CASCADE on UPDATE CASCADE,
	INDEX ind_hat_shipping_addresses_id (hat_shipping_addresses_id),
	CONSTRAINT fk_hat_shipping_addresses_id FOREIGN KEY (shipping_addresses_id) REFERENCES hat_shipping_addresses(hat_shipping_addresses_id)
	ON DELETE CASCADE on UPDATE CASCADE,
	INDEX ind_hat_carriers_methods_id (carriers_methods_id),
	CONSTRAINT fk_hat_carriers_methods_id FOREIGN KEY (carriers_methods_id) REFERENCES hat_carriers_methods(hat_carriers_methods_id)
	ON DELETE CASCADE on UPDATE CASCADE,
	INDEX ind_hat_billing_addresses_id (billing_addresses_id),
	CONSTRAINT fk_hat_billing_addresses_id FOREIGN KEY (billing_addresses_id) REFERENCES billing_addresses(hat_billing_addresses_id)
	ON DELETE CASCADE on UPDATE CASCADE
) ENGINE = InnoDB;

create table categories(
	categories_id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
	category VARCHAR(100) NOT NULL,
	description VARCHAR(1000),
	PRIMARY KEY(categories_id)
) ENGINE = InnoDB;

create table sizes(
	sizes_id TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
	size VARCHAR(20) NOT NULL,
	PRIMARY KEY(sizes_id)
) ENGINE = InnoDB;

INSERT INTO sizes (size) VALUES
	('xxx-small'),
	('xx-small'),
	('x-small'),
	('small'),
	('medium'),
	('large'),
	('x-large'),
	('xx-large'),
	('xxx-large');
	
create table shirt_colors(
	hat_colors_id TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
	keyword VARCHAR(20) NOT NULL,
	code VARCHAR(20) NOT NULL,
	PRIMARY KEY(hat_colors_id)
) ENGINE = InnoDB;

INSERT INTO colors (keyword, code) VALUES
	('black', '#000000'),
	('white', '#ffffff'),
	('blue', '#0000FF'),
	('dark blue', '#0000A0'),
	('light blue', '#ADD8E6'),
	('red', '#FF0000'),
	('cyan', '#00FFFF'),
	('purple', '#800080'),
	('yellow', '#FFFF00'),
	('lime', '#00FF00'),
	('magenta', '#FF00FF'),
	('silver', '#C0C0C0'),
	('gray', '#808080'),
	('orange', '#FFA500'),
	('brown', '#A52A2A'),
	('maroon', '#800000'),
	('green', '#008000'),
	('olive', '#808000');

create table hats(
	hats_id MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
	hat_categories_id SMALLINT UNSIGNED NOT NULL,
	hat_sizes_id TINYINT UNSIGNED NOT NULL,
	hat_colors_id TINYINT UNSIGNED NOT NULL,
	price DECIMAL(6,3) NOT NULL,
	photo VARCHAR(100),
	stock_quantity MEDIUMINT UNSIGNED NOT NULL,
	date_added TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY(hats_id),
	INDEX _categories_id (categories_id),
	CONSTRAINT _categories_id FOREIGN KEY (hat_categories_id) REFERENCES categories(categories_id)
	ON DELETE CASCADE on UPDATE CASCADE,
	INDEX fk_hat_sizes_id (sizes_id),
	CONSTRAINT fk_hat_sizes_id FOREIGN KEY (sizes_id) REFERENCES sizes(sizes_id)
	ON DELETE CASCADE on UPDATE CASCADE,
	INDEX ind_hat_colors_id (colors_id),
	CONSTRAINT fk_hat_colors_id FOREIGN KEY (colors_id) REFERENCES colors(colors_id)
	ON DELETE CASCADE on UPDATE CASCADE
) ENGINE = InnoDB;

create table orders(
	orders_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
	orders_id INT UNSIGNED NOT NULL,
	hats_id MEDIUMINT UNSIGNED NOT NULL,
	quantity TINYINT UNSIGNED NOT NULL,
	price DECIMAL(7,3) NOT NULL,
	PRIMARY KEY(hat_orders_hats_id),
	INDEX ind_hat_orders_id (hat_orders_id),
	CONSTRAINT fk_hat_orders_id FOREIGN KEY (hat_orders_id) REFERENCES hat_orders(hat_orders_id)
	ON DELETE CASCADE on UPDATE CASCADE,
	INDEX ind_hats_id (hats_id),
	CONSTRAINT fk_hats_id FOREIGN KEY (hats_id) REFERENCES hats(hats_id)
	ON DELETE CASCADE on UPDATE CASCADE
) ENGINE = InnoDB;


create table carts(
	carts_id MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT,
	customers_id MEDIUMINT UNSIGNED NOT NULL, 
	id MEDIUMINT UNSIGNED NOT NULL, 
	quantity TINYINT UNSIGNED NOT NULL, 
	date_added TIMESTAMP NOT NULL, 
	date_modified TIMESTAMP NOT NULL, 
	PRIMARY KEY(carts_id),
	INDEX ind_hat_customers_id (customers_id),
	CONSTRAINT fk_carts_hat_customers_id FOREIGN KEY (customers_id) REFERENCES customers(customers_id)
	ON DELETE CASCADE on UPDATE CASCADE,
	INDEX ind_hats_id (hats_id),
	CONSTRAINT fk_carts_hats_id FOREIGN KEY (hats_id) REFERENCES hats(hats_id)
	ON DELETE CASCADE on UPDATE CASCADE
) ENGINE = InnoDB;

ALTER TABLE hat_customers MODIFY COLUMN address_2 varchar(100);
ALTER TABLE hat_shipping_addresses MODIFY COLUMN address_2 varchar(100);
ALTER TABLE hat_billing_addresses MODIFY COLUMN address_2 varchar(100);


INSERT INTO customers (first_name, last_name, email, phone, password, address_1, address_2, city, hat_states_id, zip, date_created) VALUES
	('David', 'Steel', 'dsteel@ysu.edu', '330-333-4444', 'mypassword', 'One University Plaza', 'Youngstown State University - Meshel Hall #123', 'Youngstown', 36, '44555', current_timestamp),
	('Mark', 'Jordan', 'mjordan@gmail.com', '330-444-5555', 'mypassword', '123 Main Street', '', 'Youngstown', 36, '44555', current_timestamp),
	('Mary', 'Alan', 'malan@yahoo.com', '330-555-6666', 'mypassword', '5068 South Avenue', '', 'Boardman', 36, '44512', current_timestamp);
	
INSERT INTO transactions (amount_charged, type, response_code, response_reason, response_text, date_created) VALUES
	(48.98, 'regular', '100', '', 'OK', current_timestamp),
	(22.98, 'regular', '100', '', 'OK', current_timestamp);

INSERT INTO shipping_addresses (address_1, address_2, city, hat_states_id, zip, date_created) VALUES 
	('One University Plaza', 'Youngstown State University - Meshel Hall #123', 'Youngstown', 36, '44555', current_timestamp);

INSERT INTO billing_addresses (address_1, address_2, city, hat_states_id, zip, date_created) VALUES
	('100 Lockwood Avenue', '', 'Canfield', 36, '44406', current_timestamp);	

INSERT INTO hat_orders (hat_customers_id, hat_transactions_id, hat_shipping_addresses_id, hat_billing_addresses_id, hat_carriers_methods_id, credit_no, credit_type, order_total, shipping_fee, shipping_date, order_date) VALUES
	(1, 1, 1, 1, 3, '4345', 'Visa', 43.99, 4.99, current_timestamp, current_timestamp),
	(1, 2, 1, 1, 4, '4345', 'Visa', 19.99, 2.99, current_timestamp, current_timestamp);
	
select * from hat_customers;
select * from hat_transactions;
select * from hat_shipping_addresses;
select * from hat_billing_addresses;
select * from hat_orders;

SELECT first_name, last_name, credit_no, credit_type FROM hat_customers, hat_orders 
	WHERE hat_customers.hat_customers_id = hat_orders.hat_customers_id;

SELECT first_name, last_name, credit_no, credit_type FROM hat_customers 
	INNER JOIN hat_orders ON hat_customers.hat_customers_id = hat_orders.hat_customers_id;

SELECT first_name, last_name, credit_no, credit_type FROM hat_customers 
	INNER JOIN hat_orders USING (customers_id);
	
SELECT first_name, last_name, credit_no, credit_type, CONCAT_WS(' ', hat_shipping_addresses.address_1, hat_shipping_addresses.address_2, hat_shipping_addresses.city, state, hat_shipping_addresses.zip) as 'Shipping Address' FROM hat_customers 
	INNER JOIN hat_orders USING (customers_id)
	INNER JOIN hat_shipping_addresses USING (shipping_addresses_id)
	INNER JOIN hat_states ON hat_shipping_addresses.hat_states_id = hat_states.hat_states_id;

SELECT first_name, last_name, credit_no, credit_type, CONCAT_WS(' ', hat_shipping_addresses.address_1, hat_shipping_addresses.address_2, hat_shipping_addresses.city, state, hat_shipping_addresses.zip) as 'Shipping Address' FROM hat_customers 
	LEFT JOIN hat_orders USING (customers_id)
	LEFT JOIN hat_shipping_addresses USING (shipping_addresses_id)
	LEFT JOIN hat_states ON hat_shipping_addresses.hat_states_id = hat_states.hat_states_id 
	WHERE hat_shipping_addresses.city = 'Youngstown'
	ORDER BY last_name ASC
	;
	
SELECT first_name, last_name, credit_no, credit_type, CONCAT_WS(' ', hat_shipping_addresses.address_1, hat_shipping_addresses.address_2, hat_shipping_addresses.city, state, hat_shipping_addresses.zip) as 'Shipping Address' FROM hat_states 
	RIGHT JOIN shipping_addresses ON hat_shipping_addresses.hat_states_id = hat_states.hat_states_id 
	RIGHT JOIN orders USING (shipping_addresses_id)
	RIGHT JOIN customers USING (customers_id);
	
	

	
/*
 
 
 
 */
 
